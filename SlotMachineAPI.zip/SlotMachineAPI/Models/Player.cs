﻿using System.ComponentModel.DataAnnotations;

namespace SlotMachineAPI.Models
{
	public class Player
	{
		public int PlayerId { get; set; }

		[Required]
		[RegularExpression(@"^\d{4}-\d{2}$", ErrorMessage = "Student number must be in the format 'XXXX-XX'.")]
		public string StudentNumber { get; set; } = string.Empty;

		[Required]
		public string FirstName { get; set; } = string.Empty;

		[Required]
		public string LastName { get; set; } = string.Empty;

		public DateTime CreatedAt { get; set; } = DateTime.Now;

		// Add CooldownDate to track cooldown
		public DateTime? CooldownDate { get; set; }  // Nullable DateTime for tracking cooldown

		public ICollection<GameResult> GameResults { get; set; } = new List<GameResult>();
	}
}
