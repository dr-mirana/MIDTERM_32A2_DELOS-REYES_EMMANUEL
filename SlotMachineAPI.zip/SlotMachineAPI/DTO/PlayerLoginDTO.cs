﻿namespace SlotMachineAPI.DTO
{
	public class PlayerLoginDTO
	{
		public string StudentNumber { get; set; }
	}
}
