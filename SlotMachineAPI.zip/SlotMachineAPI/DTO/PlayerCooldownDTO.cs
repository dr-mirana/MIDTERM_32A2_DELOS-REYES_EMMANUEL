﻿namespace SlotMachineAPI.DTO
{
	public class PlayerCooldownDTO
	{
		public string StudentNumber { get; set; }
		public DateTime CooldownDate { get; set; }
	}
}
