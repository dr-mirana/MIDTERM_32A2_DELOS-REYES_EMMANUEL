﻿using System.ComponentModel.DataAnnotations;

namespace SlotMachineAPI.DTO
{
	public class GameResultDTO
	{
		[Required]
		[RegularExpression(@"^\d{4}-\d{2}$", ErrorMessage = "Student number must be in the format 2069-22.")]
		public string StudentNumber { get; set; } = string.Empty;

		[Required]
		[RegularExpression("^(Win|Loss)$", ErrorMessage = "Outcome must be either 'Win' or 'Loss'.")]
		public string Outcome { get; set; } = string.Empty;

		[Range(1, 3, ErrorMessage = "Tries must be between 1 and 3.")]
		public int Tries { get; set; }
	}
}
