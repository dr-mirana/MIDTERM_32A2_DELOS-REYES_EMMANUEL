﻿using Microsoft.EntityFrameworkCore;
using SlotMachineAPI.Models;
public class SlotMachineDbContext : DbContext
{
	public SlotMachineDbContext(DbContextOptions<SlotMachineDbContext> options)
		: base(options) { }

	public DbSet<Player> Players { get; set; }
	public DbSet<GameResult> GameResults { get; set; }
	public DbSet<Admin> Admins { get; set; }

	protected override void OnModelCreating(ModelBuilder modelBuilder)
	{
		modelBuilder.Entity<Player>()
			.HasIndex(p => p.StudentNumber)
			.IsUnique();

		modelBuilder.Entity<GameResult>()
			.HasOne(gr => gr.Player)
			.WithMany(p => p.GameResults) // Assuming Player has a collection of GameResults
			.HasForeignKey(gr => gr.PlayerId);

		modelBuilder.Entity<Admin>()
			.HasIndex(a => a.Username)
			.IsUnique();
	}
}