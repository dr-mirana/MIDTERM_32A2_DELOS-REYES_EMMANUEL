﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SlotMachineAPI.DTO;
using SlotMachineAPI.Models;
using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

[Route("api/[controller]")]
[ApiController]
public class GameResultsController : ControllerBase
{
	private readonly SlotMachineDbContext _context;
	private readonly ILogger<GameResultsController> _logger;

	public GameResultsController(SlotMachineDbContext context, ILogger<GameResultsController> logger)
	{
		_context = context;
		_logger = logger;
	}

	// Player Login Endpoint
	[HttpPost("login")]
	public async Task<IActionResult> PlayerLogin([FromBody] PlayerLoginDTO loginDTO)
	{
		var player = await _context.Players
			.FirstOrDefaultAsync(p => p.StudentNumber == loginDTO.StudentNumber);

		if (player == null)
		{
			return BadRequest(new { message = "Player not found." });
		}

		var gameResult = await _context.GameResults
			.FirstOrDefaultAsync(gr => gr.PlayerId == player.PlayerId);

		if (gameResult == null)
		{
			gameResult = new GameResult
			{
				PlayerId = player.PlayerId,
				Outcome = "Pending",
				Tries = 0,
				DatePlayed = DateTime.Now
			};
			_context.GameResults.Add(gameResult);
			await _context.SaveChangesAsync();
		}

		return Ok(new { message = "Login successful!" });
	}

	// Save Game Result
	[HttpPost("save-result")]
	public async Task<IActionResult> SaveResult([FromBody] GameResultDTO dto)
	{
		var player = await _context.Players
			.FirstOrDefaultAsync(p => p.StudentNumber == dto.StudentNumber);

		if (player == null)
		{
			return BadRequest(new { message = "Invalid player, please check the Student Number." });
		}

		if (dto.Tries < 1 || dto.Tries > 3)
		{
			return BadRequest(new { message = "Tries must be between 1 and 3." });
		}

		if (dto.Outcome != "Win" && dto.Outcome != "Loss")
		{
			return BadRequest(new { message = "Outcome must be either 'Win' or 'Loss'." });
		}

		var lastPlayed = await _context.GameResults
			.Where(g => g.PlayerId == player.PlayerId)
			.OrderByDescending(g => g.DatePlayed)
			.FirstOrDefaultAsync();

		if (lastPlayed != null && lastPlayed.DatePlayed != DateTime.MinValue && lastPlayed.DatePlayed.AddHours(3) > DateTime.Now)
		{
			var timeRemaining = lastPlayed.DatePlayed.AddHours(3) - DateTime.Now;
			return BadRequest(new { message = $"Cooldown in effect. Please wait {timeRemaining.Minutes} minutes before playing again." });
		}

		var gameResult = await _context.GameResults
			.FirstOrDefaultAsync(gr => gr.PlayerId == player.PlayerId);

		if (gameResult == null)
		{
			gameResult = new GameResult
			{
				PlayerId = player.PlayerId,
				Outcome = dto.Outcome,
				Tries = dto.Tries,
				DatePlayed = DateTime.Now
			};
			_context.GameResults.Add(gameResult);
		}
		else
		{
			gameResult.Outcome = dto.Outcome;
			gameResult.Tries = dto.Tries;
			gameResult.DatePlayed = DateTime.Now;
		}

		if (dto.Outcome == "Win")
		{
			player.CooldownDate = DateTime.Now.AddHours(3);
		}

		try
		{
			await _context.SaveChangesAsync();
		}
		catch (Exception ex)
		{
			_logger.LogError($"Error saving game result: {ex.Message}");
			return StatusCode(500, new { message = "An error occurred while saving the game result." });
		}

		return Ok(new { message = "Game result saved successfully!" });
	}

	// Update Cooldown for Player
	[HttpPost("update-cooldown")]
	public async Task<IActionResult> UpdateCooldown([FromBody] PlayerCooldownDTO playerCooldownDTO)
	{
		var player = await _context.Players
			.FirstOrDefaultAsync(p => p.StudentNumber == playerCooldownDTO.StudentNumber);

		if (player == null)
		{
			return NotFound(new { message = "Player not found." });
		}

		player.CooldownDate = playerCooldownDTO.CooldownDate;
		await _context.SaveChangesAsync();
		return Ok(new { message = "Cooldown updated successfully." });
	}

	// Get Game Results for a Date Range
	[HttpGet]
	public async Task<IActionResult> GetResults(DateTime startDate, DateTime endDate)
	{
		var results = await _context.GameResults
			.Include(g => g.Player)
			.Where(g => g.DatePlayed >= startDate && g.DatePlayed <= endDate)
			.Select(g => new
			{
				player = $"{g.Player.FirstName} {g.Player.LastName}",
				studentNumber = g.Player.StudentNumber,
				outcome = g.Outcome,
				datePlayed = g.DatePlayed
			})
			.OrderByDescending(g => g.datePlayed)
			.ToListAsync();

		return Ok(results);
	}

	// Get Winners for a Date Range
	[HttpGet("winners")]
	public async Task<IActionResult> GetWinners(DateTime startDate, DateTime endDate)
	{
		var winners = await _context.GameResults
			.Include(g => g.Player)
			.Where(g => g.Outcome == "Win" && g.DatePlayed >= startDate && g.DatePlayed <= endDate)
			.Select(g => new
			{
				player = $"{g.Player.FirstName} {g.Player.LastName}",
				studentNumber = g.Player.StudentNumber,
				datePlayed = g.DatePlayed
			})
			.OrderByDescending(g => g.datePlayed)
			.ToListAsync();

		return Ok(winners);
	}

	// Get Recent Players within last 3 hours
	[HttpGet("recent-players")]
	public async Task<IActionResult> GetRecentPlayers()
	{
		var threeHoursAgo = DateTime.Now.AddHours(-3);

		var recentPlayers = await _context.GameResults
			.Include(g => g.Player)
			.Where(g => g.DatePlayed >= threeHoursAgo)
			.Select(g => new
			{
				player = $"{g.Player.FirstName} {g.Player.LastName}",
				studentNumber = g.Player.StudentNumber,
				lastPlayed = g.DatePlayed
			})
			.OrderByDescending(g => g.lastPlayed)
			.ToListAsync();

		return Ok(recentPlayers);
	}
}
